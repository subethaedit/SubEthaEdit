/**********************************************************************

  utf32_be.c -  Oniguruma (regular expression library)

  Copyright (C) 2004  K.Kosako (kosako@sofnec.co.jp)

**********************************************************************/
#include "regenc.h"

static int
utf32be_mbc_enc_len(UChar* p)
{
  return 4;
}

static int
utf32be_is_mbc_newline(UChar* p, UChar* end)
{
  if (p + 3 < end) {
    if (*(p+3) == 0x0a && *(p+2) == 0 && *(p+1) == 0 && *p == 0)
      return 1;
  }
  return 0;
}

static OnigCodePoint
utf32be_mbc_to_code(UChar* p, UChar* end)
{
  return (OnigCodePoint )(((p[0] * 256 + p[1]) * 256 + p[2]) * 256 + p[3]);
}

static int
utf32be_code_to_mbclen(OnigCodePoint code)
{
  return 4;
}

static int
utf32be_code_to_mbc(OnigCodePoint code, UChar *buf)
{
  UChar* p = buf;

  *p++ = (UChar )((code & 0xff000000) >>24);
  *p++ = (UChar )((code & 0xff0000)   >>16);
  *p++ = (UChar )((code & 0xff00)     >> 8);
  *p++ = (UChar ) (code & 0xff);
  return 4;
}

static int
utf32be_mbc_to_normalize(OnigAmbigType flag, UChar** pp, UChar* end,
                         UChar* lower)
{
  UChar* p = *pp;

  if (*(p+2) == 0 && *(p+1) == 0 && *p == 0) {
    p += 3;
    if (end > p + 4 &&
        ((*p == 'S' && *(p+4) == 'S') || (*p == 's' && *(p+4) == 's')) &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_COMPOUND) != 0 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE) != 0 &&
        *(p+3) == 0 && *(p+2) == 0 && *(p+1) == 0) {
      *lower++ = '\0';
      *lower++ = '\0';
      *lower++ = '\0';
      *lower   = 0xdf;
      (*pp) += 8;
      return 4;
    }

    *lower++ = '\0';
    *lower++ = '\0';
    *lower++ = '\0';
    if ((flag & (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
                 ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE)) != 0) {
      *lower = ONIGENC_ISO_8859_1_TO_LOWER_CASE(*p);
    }
    else {
      *lower = *p;
    }

    (*pp) += 4;
    return 4;  /* return byte length of converted char to lower */
  }
  else {
    int len = 4;
    if (lower != p) {
      int i;
      for (i = 0; i < len; i++) {
	*lower++ = *p++;
      }
    }
    (*pp) += len;
    return len; /* return byte length of converted char to lower */
  }
}

static int
utf32be_is_mbc_ambiguous(OnigAmbigType flag, UChar** pp, UChar* end)
{
  UChar* p = *pp;

  (*pp) += 4;

  if (*(p+2) == 0 && *(p+1) == 0 && *p == 0) {
    int c, v;

    p += 3;
    if ((flag & ONIGENC_AMBIGUOUS_MATCH_COMPOUND) != 0 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE) != 0) {
      if (end > p + 4 &&
          ((*p == 'S' && *(p+4) == 'S') || (*p == 's' && *(p+4) == 's')) &&
          *(p+3) == 0 && *(p+2) == 0 && *(p+1) == 0) {
        (*pp) += 4;
        return TRUE;
      }
      else if (*p == 0xdf) {
        return TRUE;
      }
    }

    if ((flag & (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
                 ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE)) != 0) {
      c = *p;
      v = ONIGENC_IS_UNICODE_ISO_8859_1_CTYPE(c,
                       (ONIGENC_CTYPE_UPPER | ONIGENC_CTYPE_LOWER));

      if ((v | ONIGENC_CTYPE_LOWER) != 0) {
        /* 0xaa, 0xb5, 0xba are lower case letter, but can't convert. */
        if (c >= 0xaa && c <= 0xba)
          return FALSE;
        else
          return TRUE;
      }
      return (v != 0 ? TRUE : FALSE);
    }
  }

  return FALSE;
}

static UChar*
utf32be_left_adjust_char_head(UChar* start, UChar* s)
{
  int rem;

  if (s <= start) return s;

  rem = (s - start) % 4;
  return s - rem;
}

OnigEncodingType OnigEncodingUTF32_BE = {
  utf32be_mbc_enc_len,
  "UTF-32BE",   /* name */
  4,            /* max byte length */
  4,            /* min byte length */
  (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
   ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE |
   ONIGENC_AMBIGUOUS_MATCH_COMPOUND),
  {
      (OnigCodePoint )'\\'                       /* esc */
    , (OnigCodePoint )ONIG_INEFFECTIVE_META_CHAR /* anychar '.'  */
    , (OnigCodePoint )ONIG_INEFFECTIVE_META_CHAR /* anytime '*'  */
    , (OnigCodePoint )ONIG_INEFFECTIVE_META_CHAR /* zero or one time '?' */
    , (OnigCodePoint )ONIG_INEFFECTIVE_META_CHAR /* one or more time '+' */
    , (OnigCodePoint )ONIG_INEFFECTIVE_META_CHAR /* anychar anytime */
  },
  utf32be_is_mbc_newline,
  utf32be_mbc_to_code,
  utf32be_code_to_mbclen,
  utf32be_code_to_mbc,
  utf32be_mbc_to_normalize,
  utf32be_is_mbc_ambiguous,
  onigenc_iso_8859_1_get_all_pair_ambig_codes,
  onigenc_ess_tsett_get_all_comp_ambig_codes,
  onigenc_unicode_is_code_ctype,
  onigenc_unicode_get_ctype_code_range,
  utf32be_left_adjust_char_head,
  onigenc_always_false_is_allowed_reverse_match
};
