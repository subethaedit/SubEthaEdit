/**********************************************************************

  euc_tw.c -  Oniguruma (regular expression library)

  Copyright (C) 2004  K.Kosako (kosako@sofnec.co.jp)

**********************************************************************/
#include "regenc.h"

static int EncLen_EUCTW[] = {
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1
};

static int
euctw_mbc_enc_len(UChar* p)
{
  return EncLen_EUCTW[*p];
}

static OnigCodePoint
euctw_mbc_to_code(UChar* p, UChar* end)
{
  return onigenc_mbn_mbc_to_code(ONIG_ENCODING_EUC_TW, p, end);
}

static int
euctw_code_to_mbclen(OnigCodePoint code)
{
  return onigenc_mb4_code_to_mbclen(code);
}

static int
euctw_code_to_mbc(OnigCodePoint code, UChar *buf)
{
  return onigenc_mb4_code_to_mbc(ONIG_ENCODING_EUC_TW, code, buf);
}

static int
euctw_mbc_to_normalize(OnigAmbigType flag, UChar** pp, UChar* end,
                       UChar* lower)
{
  return onigenc_mbn_mbc_to_normalize(ONIG_ENCODING_EUC_TW, flag,
                                      pp, end, lower);
}

static int
euctw_is_mbc_ambiguous(OnigAmbigType flag, UChar** pp, UChar* end)
{
  return onigenc_mbn_is_mbc_ambiguous(ONIG_ENCODING_EUC_TW, flag, pp, end);
}

static int
euctw_is_code_ctype(OnigCodePoint code, unsigned int ctype)
{
  return onigenc_mb4_is_code_ctype(ONIG_ENCODING_EUC_TW, code, ctype);
}

#define euctw_islead(c)    (((c) < 0xa1 && (c) != 0x8e) || (c) == 0xff)

static UChar*
euctw_left_adjust_char_head(UChar* start, UChar* s)
{
  /* Assumed in this encoding,
     mb-trail bytes don't mix with single bytes.
  */
  UChar *p;
  int len;

  if (s <= start) return s;
  p = s;

  while (!euctw_islead(*p) && p > start) p--;
  len = enc_len(ONIG_ENCODING_EUC_TW, p);
  if (p + len > s) return p;
  p += len;
  return p + ((s - p) & ~1);
}

static int
euctw_is_allowed_reverse_match(UChar* s, UChar* end)
{
  UChar c = *s;
  if (c <= 0x7e) return TRUE;
  else           return FALSE;
}

OnigEncodingType OnigEncodingEUC_TW = {
  euctw_mbc_enc_len,
  "EUC-TW",   /* name */
  4,          /* max enc length */
  1,          /* min enc length */
  ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE,
  onigenc_is_mbc_newline_0x0a,
  euctw_mbc_to_code,
  euctw_code_to_mbclen,
  euctw_code_to_mbc,
  euctw_mbc_to_normalize,
  euctw_is_mbc_ambiguous,
  onigenc_ascii_get_all_pair_ambig_codes,
  onigenc_nothing_get_all_comp_ambig_codes,
  euctw_is_code_ctype,
  onigenc_not_support_get_ctype_code_range,
  euctw_left_adjust_char_head,
  euctw_is_allowed_reverse_match
};
