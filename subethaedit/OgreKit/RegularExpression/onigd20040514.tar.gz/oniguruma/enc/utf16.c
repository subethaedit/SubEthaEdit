/**********************************************************************

  utf16.c -  Oniguruma (regular expression library)

  Copyright (C) 2004  K.Kosako (kosako@sofnec.co.jp)

**********************************************************************/
#include "regenc.h"

#define UTF16_IS_SURROGATE_FIRST(c)    (c >= 0xd8 && c <= 0xdb)
#define UTF16_IS_SURROGATE_SECOND(c)   (c >= 0xdc && c <= 0xdf)

static int EncLen_UTF16[] = {
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 4, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2
};

static int
utf16be_mbc_enc_len(UChar* p)
{
  return EncLen_UTF16[*p];
}

static int
utf16be_is_mbc_newline(UChar* p, UChar* end)
{
  if (p + 1 < end) {
    if (*(p+1) == 0x0a && *p == 0x00)
      return 1;
  }
  return 0;
}

static OnigCodePoint
utf16be_mbc_to_code(UChar* p, UChar* end)
{
  OnigCodePoint code;

  if (UTF16_IS_SURROGATE_FIRST(*p)) {
    code = ((((p[0] - 0xd8) << 2) + ((p[1] & 0xc0) >> 6) + 1) << 16)
         + ((((p[1] & 0x3f) << 2) + (p[2] - 0xdc)) << 8)
         + p[3];
  }
  else {
    code = p[0] * 256 + p[1];
  }
  return code;
}

static int
utf16_code_to_mbclen(OnigCodePoint code)
{
  return (code > 0xffff ? 4 : 2);
}

static int
utf16be_code_to_mbc(OnigCodePoint code, UChar *buf)
{
  UChar* p = buf;

  if (code > 0xffff) {
    unsigned int plane, high;

    plane = code >> 16;
    *p++ = (plane >> 2) + 0xd8;
    high = (code & 0xff00) >> 8;
    *p++ = ((plane & 0x03) << 6) + (high >> 2);
    *p++ = (high & 0x02) + 0xdc;
    *p   = (UChar )(code & 0xff);
    return 4;
  }
  else {
    *p++ = (UChar )((code & 0xff00) >> 8);
    *p++ = (UChar )(code & 0xff);
    return p - buf;
  }
}

static int
utf16be_mbc_to_normalize(OnigAmbigType flag, UChar** pp, UChar* end,
                         UChar* lower)
{
  UChar* p = *pp;

  if (*p == 0) {
    p++;
    if (end > p + 2 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_COMPOUND) != 0 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE) != 0 &&
        ((*p == 'S' && *(p+2) == 'S') || (*p == 's' && *(p+2) == 's')) &&
        *(p+1) == 0) {
      *lower++ = '\0';
      *lower   = 0xdf;
      (*pp) += 4;
      return 2;
    }

    *lower++ = '\0';
    if ((flag & (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
                 ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE)) != 0) {
      *lower = ONIGENC_ISO_8859_1_TO_LOWER_CASE(*p);
    }
    else {
      *lower = *p;
    }

    (*pp) += 2;
    return 2;  /* return byte length of converted char to lower */
  }
  else {
    int len;
    len = EncLen_UTF16[*p];
    if (lower != p) {
      int i;
      for (i = 0; i < len; i++) {
	*lower++ = *p++;
      }
    }
    (*pp) += len;
    return len; /* return byte length of converted char to lower */
  }
}

static int
utf16be_is_mbc_ambiguous(OnigAmbigType flag, UChar** pp, UChar* end)
{
  UChar* p = *pp;

  (*pp) += EncLen_UTF16[*p];

  if (*p == 0) {
    int c, v;

    p++;
    if ((flag & ONIGENC_AMBIGUOUS_MATCH_COMPOUND) != 0 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE) != 0) {
      if (end > p + 2 &&
          ((*p == 'S' && *(p+2) == 'S') || (*p == 's' && *(p+2) == 's')) &&
          *(p+1) == 0) {
        (*pp) += 2;
        return TRUE;
      }
      else if (*p == 0xdf) {
        return TRUE;
      }
    }

    if ((flag & (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
                 ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE)) != 0) {
      c = *p;
      v = ONIGENC_IS_UNICODE_ISO_8859_1_CTYPE(c,
                       (ONIGENC_CTYPE_UPPER | ONIGENC_CTYPE_LOWER));

      if ((v | ONIGENC_CTYPE_LOWER) != 0) {
        /* 0xaa, 0xb5, 0xba are lower case letter, but can't convert. */
        if (c >= 0xaa && c <= 0xba)
          return FALSE;
        else
          return TRUE;
      }
      return (v != 0 ? TRUE : FALSE);
    }
  }

  return FALSE;
}

static int
utf16_is_code_ctype(OnigCodePoint code, unsigned int ctype)
{
  if (code < 256) {
    return ONIGENC_IS_UNICODE_ISO_8859_1_CTYPE(code, ctype);
  }

  if ((ctype & ONIGENC_CTYPE_WORD) != 0) {
    return TRUE;
  }

  return FALSE;
}

static int
utf16_get_ctype_code_range(int ctype, int* nsb, int* nmb,
		  OnigCodePointRange* sbr[], OnigCodePointRange* mbr[])
{
#define CR_SET(list) do { \
  *nsb = 0; \
  *nmb = sizeof(list) / sizeof(OnigCodePointRange); \
  *mbr = list; \
} while (0)


  static OnigCodePointRange CRAlpha[] = {
    { 0x41, 0x5a },
    { 0x61, 0x7a },
    { 0xaa, 0xaa },
    { 0xb5, 0xb5 },
    { 0xba, 0xba },
    { 0xc0, 0xd6 },
    { 0xd8, 0xf6 },
    { 0xf8, 0x220 }
  };

  static OnigCodePointRange CRBlank[] = {
    { 0x09, 0x09 },
    { 0x20, 0x20 },
    { 0xa0, 0xa0 }
  };

  static OnigCodePointRange CRCntrl[] = {
    { 0x00, 0x1f },
    { 0x7f, 0x7f },
    { 0x80, 0x9f }
  };

  static OnigCodePointRange CRDigit[] = {
    { 0x30, 0x39 }
  };

  static OnigCodePointRange CRGraph[] = {
    { 0x21, 0x7e },
    { 0xa1, 0x220 }
  };

  static OnigCodePointRange CRLower[] = {
    { 0x61, 0x7a },
    { 0xaa, 0xaa },
    { 0xb5, 0xb5 },
    { 0xba, 0xba },
    { 0xdf, 0xf6 },
    { 0xf8, 0xff }
  };

  static OnigCodePointRange CRPrint[] = {
    { 0x20, 0x7e },
    { 0xa0, 0x220 }
  };

  static OnigCodePointRange CRPunct[] = {
    { 0x21, 0x23 },
    { 0x25, 0x2a },
    { 0x2c, 0x2f },
    { 0x3a, 0x3b },
    { 0x3f, 0x40 },
    { 0x5b, 0x5d },
    { 0x5f, 0x5f },
    { 0x7b, 0x7b },
    { 0x7d, 0x7d },
    { 0xa1, 0xa1 },
    { 0xab, 0xab },
    { 0xad, 0xad },
    { 0xb7, 0xb7 },
    { 0xbb, 0xbb },
    { 0xbf, 0xbf }
  };

  static OnigCodePointRange CRSpace[] = {
    { 0x09, 0x0d },
    { 0x20, 0x20 },
    { 0xa0, 0xa0 }
  };

  static OnigCodePointRange CRUpper[] = {
    { 0x41, 0x5a },
    { 0xc0, 0xd6 },
    { 0xd8, 0xde }
  };

  static OnigCodePointRange CRXDigit[] = {
    { 0x30, 0x39 },
    { 0x41, 0x46 },
    { 0x61, 0x66 }
  };

  static OnigCodePointRange CRWord[] = {
    { 0x30, 0x39 },
    { 0x41, 0x5a },
    { 0x5f, 0x5f },
    { 0x61, 0x7a },
    { 0xaa, 0xaa },
    { 0xb2, 0xb3 },
    { 0xb5, 0xb5 },
    { 0xb9, 0xba },
    { 0xbc, 0xbe },
    { 0xc0, 0xd6 },
    { 0xd8, 0xf6 },
#if 0
    { 0xf8, 0x220 }
#else
    { 0xf8, 0x7fffffff } /* all multibyte code as word */
#endif
  };

  static OnigCodePointRange CRAscii[] = {
    { 0x00, 0x7f }
  };

  static OnigCodePointRange CRAlnum[] = {
    { 0x30, 0x39 },
    { 0x41, 0x5a },
    { 0x61, 0x7a },
    { 0xaa, 0xaa },
    { 0xb5, 0xb5 },
    { 0xba, 0xba },
    { 0xc0, 0xd6 },
    { 0xd8, 0xf6 },
    { 0xf8, 0x220 }
  };

  switch (ctype) {
  case ONIGENC_CTYPE_ALPHA:
    CR_SET(CRAlpha);
    break;
  case ONIGENC_CTYPE_BLANK:
    CR_SET(CRBlank);
    break;
  case ONIGENC_CTYPE_CNTRL:
    CR_SET(CRCntrl);
    break;
  case ONIGENC_CTYPE_DIGIT:
    CR_SET(CRDigit);
    break;
  case ONIGENC_CTYPE_GRAPH:
    CR_SET(CRGraph);
    break;
  case ONIGENC_CTYPE_LOWER:
    CR_SET(CRLower);
    break;
  case ONIGENC_CTYPE_PRINT:
    CR_SET(CRPrint);
    break;
  case ONIGENC_CTYPE_PUNCT:
    CR_SET(CRPunct);
    break;
  case ONIGENC_CTYPE_SPACE:
    CR_SET(CRSpace);
    break;
  case ONIGENC_CTYPE_UPPER:
    CR_SET(CRUpper);
    break;
  case ONIGENC_CTYPE_XDIGIT:
    CR_SET(CRXDigit);
    break;
  case ONIGENC_CTYPE_WORD:
    CR_SET(CRWord);
    break;
  case ONIGENC_CTYPE_ASCII:
    CR_SET(CRAscii);
    break;
  case ONIGENC_CTYPE_ALNUM:
    CR_SET(CRAlnum);
    break;

  default:
    return ONIGENCERR_TYPE_BUG;
    break;
  }

  return 0;
}

#if 0
static int
utf16be_get_fold_match_info(UChar* p, UChar* end, OnigEncFoldMatchInfo** info)
{
  static OnigEncFoldMatchInfo ess_tsett_be = {
    3,
    { 2, 4, 4 },
    {
      "\000\337",         /* \U+00DF */
      "\000\163\000\163", /* "ss"    */
      "\000\123\000\123"  /* "SS"    */
    }
  };

  if (*p == 0) {
    p++;
    *info = &ess_tsett_be;
    if (*p == 0xdf)
      return 2;
    else if (*p == 's') {
      p++;
      if (*(p + 1) == 's' && *p == 0)
        return 4;
    }
    else if (*p == 'S') {
      p++;
      if (*(p + 1) == 'S' && *p == 0)
        return 4;
    }
  }

  return -1; /* is not a fold string. */
}
#endif

static UChar*
utf16be_left_adjust_char_head(UChar* start, UChar* s)
{
  if (s <= start) return s;

  if ((s - start) % 2 == 1) {
    s--;
  }

  if (UTF16_IS_SURROGATE_SECOND(*s) && s > start + 1)
    s -= 2;

  return s;
}

static int
utf16_is_allowed_reverse_match(UChar* s, UChar* end)
{
  return TRUE;
}

OnigEncodingType OnigEncodingUTF16_BE = {
  utf16be_mbc_enc_len,
  "UTF-16 BE",  /* name */
  4,            /* max byte length */
  2,            /* min byte length */
  (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
   ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE |
   ONIGENC_AMBIGUOUS_MATCH_COMPOUND),
  utf16be_is_mbc_newline,
  utf16be_mbc_to_code,
  utf16_code_to_mbclen,
  utf16be_code_to_mbc,
  utf16be_mbc_to_normalize,
  utf16be_is_mbc_ambiguous,
  onigenc_iso_8859_1_get_all_pair_ambig_codes,
  onigenc_ess_tsett_get_all_comp_ambig_codes,
  utf16_is_code_ctype,
  utf16_get_ctype_code_range,
  utf16be_left_adjust_char_head,
  utf16_is_allowed_reverse_match
};


static int
utf16le_mbc_enc_len(UChar* p)
{
  return EncLen_UTF16[*(p+1)];
}

static int
utf16le_is_mbc_newline(UChar* p, UChar* end)
{
  if (p + 1 < end) {
    if (*p == 0x0a && *(p+1) == 0x00)
      return 1;
  }
  return 0;
}

static OnigCodePoint
utf16le_mbc_to_code(UChar* p, UChar* end)
{
  OnigCodePoint code;
  UChar c0 = *p;
  UChar c1 = *(p+1);

  if (UTF16_IS_SURROGATE_FIRST(c1)) {
    code = ((((c1 - 0xd8) << 2) + ((c0  & 0xc0) >> 6) + 1) << 16)
         + ((((c0 & 0x3f) << 2) + (p[3] - 0xdc)) << 8)
         + p[2];
  }
  else {
    code = c1 * 256 + p[0];
  }
  return code;
}

static int
utf16le_code_to_mbc(OnigCodePoint code, UChar *buf)
{
  UChar* p = buf;

  if (code > 0xffff) {
    unsigned int plane, high;

    plane = code >> 16;
    high = (code & 0xff00) >> 8;

    *p++ = ((plane & 0x03) << 6) + (high >> 2);
    *p++ = (plane >> 2) + 0xd8;
    *p++ = (UChar )(code & 0xff);
    *p   = (high & 0x02) + 0xdc;
    return 4;
  }
  else {
    *p++ = (UChar )(code & 0xff);
    *p++ = (UChar )((code & 0xff00) >> 8);
    return p - buf;
  }
}

static int
utf16le_mbc_to_normalize(OnigAmbigType flag, UChar** pp, UChar* end,
                         UChar* lower)
{
  UChar* p = *pp;

  if (*(p+1) == 0) {
    if (end > p + 3 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_COMPOUND) != 0 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE) != 0 &&
        ((*p == 'S' && *(p+2) == 'S') || (*p == 's' && *(p+2) == 's')) &&
        *(p+3) == 0) {
      *lower++ = 0xdf;
      *lower   = '\0';
      (*pp) += 4;
      return 2;
    }

    *(lower+1) = '\0';
    if ((flag & (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
                 ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE)) != 0) {
      *lower = ONIGENC_ISO_8859_1_TO_LOWER_CASE(*p);
    }
    else {
      *lower = *p;
    }
    (*pp) += 2;
    return 2;  /* return byte length of converted char to lower */
  }
  else {
    int len = EncLen_UTF16[*(p+1)];
    if (lower != p) {
      int i;
      for (i = 0; i < len; i++) {
	*lower++ = *p++;
      }
    }
    (*pp) += len;
    return len; /* return byte length of converted char to lower */
  }
}

static int
utf16le_is_mbc_ambiguous(OnigAmbigType flag, UChar** pp, UChar* end)
{
  UChar* p = *pp;

  (*pp) += EncLen_UTF16[*(p+1)];

  if (*(p+1) == 0) {
    int c, v;

    if ((flag & ONIGENC_AMBIGUOUS_MATCH_COMPOUND) != 0 &&
        (flag & ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE) != 0) {
      if (end > p + 3 &&
          ((*p == 'S' && *(p+2) == 'S') || (*p == 's' && *(p+2) == 's')) &&
          *(p+3) == 0) {
        (*pp) += 2;
        return TRUE;
      }
    }

    if ((flag & (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
                 ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE)) != 0) {
      c = *p;
      v = ONIGENC_IS_UNICODE_ISO_8859_1_CTYPE(c,
                       (ONIGENC_CTYPE_UPPER | ONIGENC_CTYPE_LOWER));

      if ((v | ONIGENC_CTYPE_LOWER) != 0) {
        /* 0xaa, 0xb5, 0xba are lower case letter, but can't convert. */
        if (c >= 0xaa && c <= 0xba)
          return FALSE;
        else
          return TRUE;
      }
      return (v != 0 ? TRUE : FALSE);
    }
  }

  return FALSE;
}

static UChar*
utf16le_left_adjust_char_head(UChar* start, UChar* s)
{
  if (s <= start) return s;

  if ((s - start) % 2 == 1) {
    s--;
  }

  if (UTF16_IS_SURROGATE_SECOND(*(s+1)) && s > start + 1)
    s -= 2;

  return s;
}

OnigEncodingType OnigEncodingUTF16_LE = {
  utf16le_mbc_enc_len,
  "UTF-16 LE",  /* name */
  4,            /* max byte length */
  2,            /* min byte length */
  (ONIGENC_AMBIGUOUS_MATCH_ASCII_CASE |
   ONIGENC_AMBIGUOUS_MATCH_NONASCII_CASE |
   ONIGENC_AMBIGUOUS_MATCH_COMPOUND),
  utf16le_is_mbc_newline,
  utf16le_mbc_to_code,
  utf16_code_to_mbclen,
  utf16le_code_to_mbc,
  utf16le_mbc_to_normalize,
  utf16le_is_mbc_ambiguous,
  onigenc_iso_8859_1_get_all_pair_ambig_codes,
  onigenc_ess_tsett_get_all_comp_ambig_codes,
  utf16_is_code_ctype,
  utf16_get_ctype_code_range,
  utf16le_left_adjust_char_head,
  utf16_is_allowed_reverse_match
};
