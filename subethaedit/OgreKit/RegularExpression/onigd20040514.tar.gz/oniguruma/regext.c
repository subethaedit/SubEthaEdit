/**********************************************************************

  regext.c -  Oniguruma (regular expression library)

  Copyright (C) 2004  K.Kosako (kosako@sofnec.co.jp)

**********************************************************************/
#include "regint.h"


static void
conv_ext0be(UChar* s, UChar* end, UChar* conv)
{
  while (s < end) {
    *conv++ = '\0';
    *conv++ = *s;
    s++;
  }
}

static void
conv_ext0le(UChar* s, UChar* end, UChar* conv)
{
  while (s < end) {
    *conv++ = *s;
    *conv++ = '\0';
    s++;
  }
}

static void
conv_swap2bytes(UChar* s, UChar* end, UChar* conv)
{
  while (s < end) {
    *conv++ = s[1];
    *conv++ = s[0];
    s += 2;
  }
}

static int
conv_encoding(OnigEncoding from, OnigEncoding to, UChar* s, UChar* end,
              UChar** conv, UChar** conv_end)
{
  int len = end - s;

  if (to == ONIG_ENCODING_UTF16_BE) {
    if (from == ONIG_ENCODING_ASCII || from == ONIG_ENCODING_ISO_8859_1) {
      *conv = (UChar* )xmalloc(len * 2);
      CHECK_NULL_RETURN_VAL(*conv, ONIGERR_MEMORY);
      *conv_end = *conv + (len * 2);
      conv_ext0be(s, end, *conv);
      return 0;
    }
    else if (from == ONIG_ENCODING_UTF16_LE) {
    swap:
      *conv = (UChar* )xmalloc(len);
      CHECK_NULL_RETURN_VAL(*conv, ONIGERR_MEMORY);
      *conv_end = *conv + len;
      conv_swap2bytes(s, end, *conv);
      return 0;
    }
  }
  else if (to == ONIG_ENCODING_UTF16_LE) {
    if (from == ONIG_ENCODING_ASCII || from == ONIG_ENCODING_ISO_8859_1) {
      *conv = (UChar* )xmalloc(len * 2);
      CHECK_NULL_RETURN_VAL(*conv, ONIGERR_MEMORY);
      *conv_end = *conv + (len * 2);
      conv_ext0le(s, end, *conv);
      return 0;
    }
    else if (from == ONIG_ENCODING_UTF16_BE) {
      goto swap;
    }
  }

  return ONIGERR_NOT_SUPPORTED_ENCODING_COMBINATION;
}

extern int
onig_new_deluxe(regex_t** reg, UChar* pattern, UChar* pattern_end,
                OnigOptionType option, OnigAmbigType ambig_flag,
                OnigEncoding pattern_enc, OnigEncoding target_enc,
                OnigSyntaxType* syntax, OnigErrorInfo* einfo)
{
  int r;
  UChar *cpat, *cpat_end;

  if (IS_NOT_NULL(einfo)) einfo->par = (UChar* )NULL;

  if (pattern_enc != target_enc) {
    r = conv_encoding(pattern_enc, target_enc, pattern, pattern_end,
                      &cpat, &cpat_end);
    if (r) return r;
  }
  else {
    cpat     = pattern;
    cpat_end = pattern_end;
  }

  r = onig_alloc_init(reg, option, ambig_flag, target_enc, syntax);
  if (r) goto err;

  r = onig_compile(*reg, cpat, cpat_end, einfo);
  if (r) {
    onig_free(*reg);
    *reg = NULL;
  }

 err:
  if (cpat != pattern) xfree(cpat);

  return r;
}

extern int
onig_recompile_deluxe(regex_t* reg, UChar* pattern, UChar* pattern_end,
	    OnigOptionType option, OnigAmbigType ambig_flag,
            OnigEncoding pattern_enc, OnigEncoding target_enc,
            OnigSyntaxType* syntax, OnigErrorInfo* einfo)
{
  int r;
  regex_t *new_reg;

  r = onig_new_deluxe(&new_reg, pattern, pattern_end, option,
                      ambig_flag, pattern_enc, target_enc, syntax, einfo);
  if (r) return r;
  if (ONIG_STATE(reg) == ONIG_STATE_NORMAL) {
    onig_transfer(reg, new_reg);
  }
  else {
    onig_chain_link_add(reg, new_reg);
  }
  return 0;
}
